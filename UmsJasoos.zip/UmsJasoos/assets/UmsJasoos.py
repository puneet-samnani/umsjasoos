import json
import os
import ijson

from random import choice

try:
    from chatterbot import ChatBot
    #from chatterbot.response_selection import response_list
    from chatterbot.trainers import ChatterBotCorpusTrainer, ListTrainer
except ImportError:
    raise ImportError("""It looks like you are missing chatterbot.
                      Please: pip install chatterbot""")

BOTS_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_PATH = os.path.join(BOTS_DIR, 'assets/var/database.db')
DIRECTORY_PATH = os.path.join(BOTS_DIR, 'assets')
VAR_PATH = os.path.join(BOTS_DIR, 'assets/var')
DB_PATH = 'assets/var/db_11307087.json'

if not os.path.exists(DIRECTORY_PATH):
    os.makedirs(DIRECTORY_PATH)

if not os.path.exists(VAR_PATH):
    os.makedirs(VAR_PATH)



# Create a new instance of a ChatBot
def create_chat_bot(no_learn):
    return ChatBot("UmsJasoos",
                   storage_adapter="chatterbot.storage.JsonFileStorageAdapter",
                   logic_adapters=
                   [
                       "chatterbot.logic.MathematicalEvaluation",
                       {
                           "import_path": "chatterbot.logic.BestMatch",
                           "response_selection_method": "chatterbot.response_selection.get_random_response",
                           "statement_comparison_function": "chatterbot.comparisons.levenshtein_distance"
                       }],
                   output_adapter="chatterbot.output.OutputAdapter",
                   output_format='text',
                   database=DATABASE_PATH,
                   silence_performance_warning="True",
     #              response_selection_method=response_list,
                   read_only=no_learn)


class UmsJasoos(object):
    '''
    This bot aims to be LPU Student's virtual assistant. It
    helps you with your queries regarding LPU admissions.
    Also helps you with information & provides you University guidance and support system .
    '''

    def usage(self):
        return '''
    This bot aims to be LPU Student's virtual assistant. It
    helps you with your queries regarding LPU admissions.
    Also helps you with information & provides you University guidance and support system .
    '''

    def initialize(self, bot_handler):
        self.bot = create_chat_bot(False)
        self.bot.set_trainer(ListTrainer)
        self.bot.train([
            "I want to contribute",
            """Contributors are more than welcomed! Please read
            https://github.com/zulip/zulip#how-to-get-involved-with-contributing-to-zulip
            to learn how to contribute.""",
        ])
        self.bot.train([
            "What is Zulip?",
            """Zulip is a powerful, open source group chat application. Written in Python
            and using the Django framework, Zulip supports both private messaging and group
            chats via conversation streams. You can learn more about the product and its
            features at https://www.zulip.org.""",
        ])
        self.bot.train([
            "I would like to request a remote dev instance",
            """Greetings! You should receive a response from one of our mentors soon.
            In the meantime, why don't you learn more about running Zulip on a development
            environment? https://zulip.readthedocs.io/en/latest/using-dev-environment.html""",
        ])
        self.bot.train([
            "Hi",
            "Hello , how can I assist you ?",
        ])
        self.bot.train([
            "Hello",
            "Hi, how can I assist you ?",
        ])
        self.bot.train([
            "What is your name?",
            "I am UmsJasoos, my job is to assist you with all your doubts and questions regarding info of LPU.",
        ])
        self.bot.train([
            "What can you do?",
            "I can provide useful information regarding your queries in LPU.",
        ])
        self.bot.train([
            "What else can you do?",
            "I can assist you in knowing about your acadenmic profile.",
        ])

        userFields = ["Name",
                      "LastSemAttendance",
                      "CGPA",
                      "HOSTLER",
                      "isMALE",
                      "DOB",
                      "PROGRAMCODE",
                      "PROGRAMNAME",
                      "TERMID",
                      "PARENTSECTION",
                      "ROLLNO",
                      "SGROUP",
                      "PSWEXPIRY",
                      "PGHNO",
                      "PGCOLONY",
                      "PGTOWN",
                      "PGDISTRICT",
                      "PGSTATE",
                      "PGCOUNTRY",
                      "CATEGORY",
                      "EMAIL",
                      "CNO",
                      "FATHER",
                      "MOTHER",
                      "EMERGENCYCNO",
                      "MCNO",
                      "FCNO",
                      "LANDLINE",
                      "FATHEREMAIL",
                      "ADDRESSLINE1",
                      "ADDRESSLINE2",
                      "TOWN",
                      "DISTRICT",
                      "STATE",
                      "COUNTRY",
                      "PIN",
                      "CRADDRESSLINE1",
                      "CRADDRESSLINE2",
                      "CRTOWN",
                      "CRDISTRICT",
                      "CRSTATE",
                      "CRCOUNTRY",
                      "CRPIN",
                      "ISDCountryName",
                      "ISDPassportNo",
                      "ISDPassportIssueDate",
                      "ISDPassportExpiryDate",
                      "ISDVisaNo",
                      "ISDVisaIssueDate",
                      "ISDVisaExpiryDate",
                      "ISDFROPermitNo",
                      "ISDFROIssueDate",
                      "ISDFROExpiryDate",
                      "ISDNationalIdNo"]

        with bot_handler.open('assets/var/userprofile.json') as data_file:
            for user in json.load(data_file):
                termid = user['TERMID']

        with bot_handler.open('assets/var/userprofile.json') as data_file:
            for user in json.load(data_file):
                for col in userFields:
                    self.bot.train([
                        "my " + col,
                        user[col],
                    ])

        with bot_handler.open('assets/var/upcomingevents.json') as data_file:
            for user in json.load(data_file):
                self.bot.train([
                    "upcoming events",
                    "on" + user['EVENTDATE'] + "," + user['EVENTTIME'] + ": " + user['EVENTTITLE'] + " at " + user[
                        'EVENTVENUE'],
                ])

        with bot_handler.open('assets/var/todays_timetable.json') as data_file:
            for user in json.load(data_file):
                self.bot.train([
                    "todays timetable",
                    user['tTIME'] + ": " + user['COURSECODE'] + " at " + user['ROOMNO'],
                ])

        with bot_handler.open('assets/var/theory.json') as data_file:
            for user in json.load(data_file):
                if (user['TERMID'] == termid and user['MaxMarks'] != -1):
                    self.bot.train([
                        "my ca marks",
                        user['courseCode'] + " " + user['Topic'] + " scored: " + user['MarksObtained'] + " out of " +
                        user['MaxMarks'],
                    ])

        with bot_handler.open('assets/var/term.json') as data_file:
            for user in json.load(data_file):
                self.bot.train([
                    "how did I get my CGPA",
                    user['TERMID'] + ", TGPA: " + user['TGPA'],
                ])

        with bot_handler.open('assets/var/term.json') as data_file:
            for user in json.load(data_file):
                self.bot.train([
                    "All sems TGPA",
                    user['TERMID'] + ", TGPA: " + user['TGPA'],
                ])

        with bot_handler.open('assets/var/practical.json') as data_file:
            for user in json.load(data_file):
                if (user['TERMID'] == termid):
                    self.bot.train([
                        "practical marks/score",
                        user['courseCode'] + " " + user['Title'] + " scored: " + user['TotalMarksObt'] + " out of " +
                        user['TotalMaxMarks'],
                    ])

        with bot_handler.open('assets/var/mymessages.json') as data_file:
            for user in json.load(data_file):
                self.bot.train([
                    "practical marks/score",
                    user['ANCDATE'] + ": " + user['TITLE'] + " - By " + user['SUBJECT'] + "\n Message:" + user[
                        'MESSAGE'],
                ])

        with bot_handler.open('assets/var/marks.json') as data_file:
            for user in json.load(data_file):
                self.bot.train((
                    "Examination Result Marks",
                    user['TERMID'] + " " + str(user['COURSECODE']) + " - " + str(user['COURSEName']) + " " + user[
                        'DESCRIPTION'] + " Scored: " + user['MARKSOBT'] + "/" + user['MAXMARKS'] + " Weighted Score: " +
                    user['WMarksObt'] + "/" + user['WeightMarksMax'],
                ))

        with bot_handler.open('assets/var/marks.json') as data_file:
            for user in json.load(data_file):
                if (user['TERMID'] == termid):
                    self.bot.train({
                        "Current/This Sem's Examination Result Marks",
                        user['TERMID'] + " " + str(user['COURSECODE']) + " - " + str(user['COURSEName']) + " " + user[
                            'DESCRIPTION'] + " Scored: " + user['MARKSOBT'] + "/" + user[
                            'MAXMARKS'] + " Weighted Score: " + user['WMarksObt'] + "/" + user['WeightMarksMax'],
                    })

        with bot_handler.open('assets/var/lpunews.json') as data_file:
            for user in json.load(data_file):
                self.bot.train([
                    "LPU NEWS",
                    user['NEWSDATE'] + ": " + user['CONTENT'],
                ])

        with bot_handler.open('assets/var/events.json') as data_file:
            for user in json.load(data_file):
                self.bot.train([
                    "Upcoming Events",
                    user['TARGETDATE'] + " : " + user['EVENT'],
                ])

        with bot_handler.open('assets/var/dyk.json') as data_file:
            for info in json.load(data_file):
                self.bot.train([
                    "Do you know about LPU",
                    info['INFO'],
                ])

        with bot_handler.open('assets/var/fess.json') as data_file:
            for user in json.load(data_file):
                self.bot.train([
                    "LAST FEE TRANSACTIONS",
                    user['FDATE'] + ": Rs." + user['AMOUNT'] + "/-  " + user['DETAIL'],
                ])




        with bot_handler.open('assets/var/courses.json') as data_file:
            for user in json.load(data_file):
                self.bot.train([
                    "list all courses",
                    user['TERMID'] + ": " + user['CourseCode'] + "-  " + user['CourseName'] + " (" + user[
                        'Credits'] + ")",
                ])

        with bot_handler.open('assets/var/attendance.json') as data_file:
            for user in json.load(data_file):
                self.bot.train([
                    "list all sem/term's attendance",
                    user['TERMID'] + ": " + user['CourseCode'] + "-  " + user['AtnDate'] + " " + user[
                        'AtnTiming'] + " Present:" + str(user['Attended'] == 1) + " DL:" + str(user['DL'] == 1),
                ])

        with bot_handler.open('assets/var/announce.json') as data_file:
            for user in json.load(data_file):
                self.bot.train([
                    "announcements",
                    user['TITLE'] + ": " + user['ANNOUNCEMENTBY'] + " " + user['CONTENT'] + " ",
                ])

        self.bot.set_trainer(ChatterBotCorpusTrainer)
        self.bot.train(
            "chatterbot.corpus.english"
        )
        self.chatterbot = create_chat_bot(True)

    def handle_message(self, message, bot_handler, state_handler):
        original_content = message['content']
        bot_response = str(self.chatterbot.get_response(original_content))
        bot_handler.send_reply(message, bot_response)


handler_class = UmsJasoos
